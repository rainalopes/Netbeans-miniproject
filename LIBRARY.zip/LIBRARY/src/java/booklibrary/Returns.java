/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "returns")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Returns.findAll", query = "SELECT r FROM Returns r"),
    @NamedQuery(name = "Returns.findByBookID", query = "SELECT r FROM Returns r WHERE r.returnsPK.bookID = :bookID"),
    @NamedQuery(name = "Returns.findByMembID", query = "SELECT r FROM Returns r WHERE r.returnsPK.membID = :membID"),
    @NamedQuery(name = "Returns.findByEmpid", query = "SELECT r FROM Returns r WHERE r.returnsPK.empid = :empid"),
    @NamedQuery(name = "Returns.findByReturnDate", query = "SELECT r FROM Returns r WHERE r.returnDate = :returnDate"),
    @NamedQuery(name = "Returns.findByFine", query = "SELECT r FROM Returns r WHERE r.fine = :fine")})
public class Returns implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReturnsPK returnsPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "return_date")
    @Temporal(TemporalType.DATE)
    private Date returnDate;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "fine")
    private String fine;

    public Returns() {
    }

    public Returns(ReturnsPK returnsPK) {
        this.returnsPK = returnsPK;
    }

    public Returns(ReturnsPK returnsPK, Date returnDate, String fine) {
        this.returnsPK = returnsPK;
        this.returnDate = returnDate;
        this.fine = fine;
    }

    public Returns(int bookID, int membID, int empid) {
        this.returnsPK = new ReturnsPK(bookID, membID, empid);
    }

    public ReturnsPK getReturnsPK() {
        return returnsPK;
    }

    public void setReturnsPK(ReturnsPK returnsPK) {
        this.returnsPK = returnsPK;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getFine() {
        return fine;
    }

    public void setFine(String fine) {
        this.fine = fine;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (returnsPK != null ? returnsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Returns)) {
            return false;
        }
        Returns other = (Returns) object;
        if ((this.returnsPK == null && other.returnsPK != null) || (this.returnsPK != null && !this.returnsPK.equals(other.returnsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.Returns[ returnsPK=" + returnsPK + " ]";
    }
    
}
