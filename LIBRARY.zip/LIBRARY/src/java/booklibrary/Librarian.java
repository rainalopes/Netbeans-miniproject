/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "librarian")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Librarian.findAll", query = "SELECT l FROM Librarian l"),
    @NamedQuery(name = "Librarian.findByEmpid", query = "SELECT l FROM Librarian l WHERE l.empid = :empid"),
    @NamedQuery(name = "Librarian.findByName", query = "SELECT l FROM Librarian l WHERE l.name = :name"),
    @NamedQuery(name = "Librarian.findByPassword", query = "SELECT l FROM Librarian l WHERE l.password = :password"),
    @NamedQuery(name = "Librarian.findByDoj", query = "SELECT l FROM Librarian l WHERE l.doj = :doj"),
    @NamedQuery(name = "Librarian.findBySalary", query = "SELECT l FROM Librarian l WHERE l.salary = :salary")})
public class Librarian implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Emp_id")
    private Integer empid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DOJ")
    @Temporal(TemporalType.DATE)
    private Date doj;
    @Basic(optional = false)
    @NotNull
    @Column(name = "salary")
    private float salary;

    public Librarian() {
    }

    public Librarian(Integer empid) {
        this.empid = empid;
    }

    public Librarian(Integer empid, String name, String password, Date doj, float salary) {
        this.empid = empid;
        this.name = name;
        this.password = password;
        this.doj = doj;
        this.salary = salary;
    }

    public Integer getEmpid() {
        return empid;
    }

    public void setEmpid(Integer empid) {
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getDoj() {
        return doj;
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (empid != null ? empid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Librarian)) {
            return false;
        }
        Librarian other = (Librarian) object;
        if ((this.empid == null && other.empid != null) || (this.empid != null && !this.empid.equals(other.empid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.Librarian[ empid=" + empid + " ]";
    }
    
}
