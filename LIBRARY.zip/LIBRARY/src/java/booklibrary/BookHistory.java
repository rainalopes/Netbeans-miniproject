/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "book_history")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BookHistory.findAll", query = "SELECT b FROM BookHistory b"),
    @NamedQuery(name = "BookHistory.findByBookID", query = "SELECT b FROM BookHistory b WHERE b.bookID = :bookID"),
    @NamedQuery(name = "BookHistory.findByReason", query = "SELECT b FROM BookHistory b WHERE b.reason = :reason")})
public class BookHistory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Book_ID")
    private Integer bookID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "reason")
    private String reason;

    public BookHistory() {
    }

    public BookHistory(Integer bookID) {
        this.bookID = bookID;
    }

    public BookHistory(Integer bookID, String reason) {
        this.bookID = bookID;
        this.reason = reason;
    }

    public Integer getBookID() {
        return bookID;
    }

    public void setBookID(Integer bookID) {
        this.bookID = bookID;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookID != null ? bookID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BookHistory)) {
            return false;
        }
        BookHistory other = (BookHistory) object;
        if ((this.bookID == null && other.bookID != null) || (this.bookID != null && !this.bookID.equals(other.bookID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.BookHistory[ bookID=" + bookID + " ]";
    }
    
}
