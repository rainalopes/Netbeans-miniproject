/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "publisher")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Publisher.findAll", query = "SELECT p FROM Publisher p"),
    @NamedQuery(name = "Publisher.findByPubid", query = "SELECT p FROM Publisher p WHERE p.pubid = :pubid"),
    @NamedQuery(name = "Publisher.findByPubName", query = "SELECT p FROM Publisher p WHERE p.pubName = :pubName"),
    @NamedQuery(name = "Publisher.findByAddress", query = "SELECT p FROM Publisher p WHERE p.address = :address"),
    @NamedQuery(name = "Publisher.findByContactNo", query = "SELECT p FROM Publisher p WHERE p.contactNo = :contactNo")})
public class Publisher implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Pub_id")
    private Integer pubid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "pub_name")
    private String pubName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "Address")
    private String address;
    @Basic(optional = false)
    @NotNull
    @Column(name = "contact_no")
    private int contactNo;

    public Publisher() {
    }

    public Publisher(Integer pubid) {
        this.pubid = pubid;
    }

    public Publisher(Integer pubid, String pubName, String address, int contactNo) {
        this.pubid = pubid;
        this.pubName = pubName;
        this.address = address;
        this.contactNo = contactNo;
    }

    public Integer getPubid() {
        return pubid;
    }

    public void setPubid(Integer pubid) {
        this.pubid = pubid;
    }

    public String getPubName() {
        return pubName;
    }

    public void setPubName(String pubName) {
        this.pubName = pubName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getContactNo() {
        return contactNo;
    }

    public void setContactNo(int contactNo) {
        this.contactNo = contactNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pubid != null ? pubid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Publisher)) {
            return false;
        }
        Publisher other = (Publisher) object;
        if ((this.pubid == null && other.pubid != null) || (this.pubid != null && !this.pubid.equals(other.pubid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.Publisher[ pubid=" + pubid + " ]";
    }
    
}
