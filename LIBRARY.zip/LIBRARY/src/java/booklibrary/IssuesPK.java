/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Mr.Lopes
 */
@Embeddable
public class IssuesPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "Book_ID")
    private int bookID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Emp_id")
    private int empid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Memb_ID")
    private int membID;

    public IssuesPK() {
    }

    public IssuesPK(int bookID, int empid, int membID) {
        this.bookID = bookID;
        this.empid = empid;
        this.membID = membID;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public int getMembID() {
        return membID;
    }

    public void setMembID(int membID) {
        this.membID = membID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) bookID;
        hash += (int) empid;
        hash += (int) membID;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IssuesPK)) {
            return false;
        }
        IssuesPK other = (IssuesPK) object;
        if (this.bookID != other.bookID) {
            return false;
        }
        if (this.empid != other.empid) {
            return false;
        }
        if (this.membID != other.membID) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.IssuesPK[ bookID=" + bookID + ", empid=" + empid + ", membID=" + membID + " ]";
    }
    
}
