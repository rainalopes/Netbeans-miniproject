/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "published by")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PublishedBy.findAll", query = "SELECT p FROM PublishedBy p"),
    @NamedQuery(name = "PublishedBy.findByBookID", query = "SELECT p FROM PublishedBy p WHERE p.publishedByPK.bookID = :bookID"),
    @NamedQuery(name = "PublishedBy.findByPubid", query = "SELECT p FROM PublishedBy p WHERE p.publishedByPK.pubid = :pubid")})
public class PublishedBy implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PublishedByPK publishedByPK;

    public PublishedBy() {
    }

    public PublishedBy(PublishedByPK publishedByPK) {
        this.publishedByPK = publishedByPK;
    }

    public PublishedBy(int bookID, int pubid) {
        this.publishedByPK = new PublishedByPK(bookID, pubid);
    }

    public PublishedByPK getPublishedByPK() {
        return publishedByPK;
    }

    public void setPublishedByPK(PublishedByPK publishedByPK) {
        this.publishedByPK = publishedByPK;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (publishedByPK != null ? publishedByPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PublishedBy)) {
            return false;
        }
        PublishedBy other = (PublishedBy) object;
        if ((this.publishedByPK == null && other.publishedByPK != null) || (this.publishedByPK != null && !this.publishedByPK.equals(other.publishedByPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.PublishedBy[ publishedByPK=" + publishedByPK + " ]";
    }
    
}
