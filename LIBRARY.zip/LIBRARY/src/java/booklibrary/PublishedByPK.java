/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Mr.Lopes
 */
@Embeddable
public class PublishedByPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "Book_ID")
    private int bookID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Pub_id")
    private int pubid;

    public PublishedByPK() {
    }

    public PublishedByPK(int bookID, int pubid) {
        this.bookID = bookID;
        this.pubid = pubid;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public int getPubid() {
        return pubid;
    }

    public void setPubid(int pubid) {
        this.pubid = pubid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) bookID;
        hash += (int) pubid;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PublishedByPK)) {
            return false;
        }
        PublishedByPK other = (PublishedByPK) object;
        if (this.bookID != other.bookID) {
            return false;
        }
        if (this.pubid != other.pubid) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.PublishedByPK[ bookID=" + bookID + ", pubid=" + pubid + " ]";
    }
    
}
