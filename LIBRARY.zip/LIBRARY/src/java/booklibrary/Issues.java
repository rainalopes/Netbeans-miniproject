/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "issues")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Issues.findAll", query = "SELECT i FROM Issues i"),
    @NamedQuery(name = "Issues.findByBookID", query = "SELECT i FROM Issues i WHERE i.issuesPK.bookID = :bookID"),
    @NamedQuery(name = "Issues.findByEmpid", query = "SELECT i FROM Issues i WHERE i.issuesPK.empid = :empid"),
    @NamedQuery(name = "Issues.findByMembID", query = "SELECT i FROM Issues i WHERE i.issuesPK.membID = :membID"),
    @NamedQuery(name = "Issues.findByIssueDate", query = "SELECT i FROM Issues i WHERE i.issueDate = :issueDate")})
public class Issues implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected IssuesPK issuesPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "issue_date")
    @Temporal(TemporalType.DATE)
    private Date issueDate;

    public Issues() {
    }

    public Issues(IssuesPK issuesPK) {
        this.issuesPK = issuesPK;
    }

    public Issues(IssuesPK issuesPK, Date issueDate) {
        this.issuesPK = issuesPK;
        this.issueDate = issueDate;
    }

    public Issues(int bookID, int empid, int membID) {
        this.issuesPK = new IssuesPK(bookID, empid, membID);
    }

    public IssuesPK getIssuesPK() {
        return issuesPK;
    }

    public void setIssuesPK(IssuesPK issuesPK) {
        this.issuesPK = issuesPK;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (issuesPK != null ? issuesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Issues)) {
            return false;
        }
        Issues other = (Issues) object;
        if ((this.issuesPK == null && other.issuesPK != null) || (this.issuesPK != null && !this.issuesPK.equals(other.issuesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.Issues[ issuesPK=" + issuesPK + " ]";
    }
    
}
