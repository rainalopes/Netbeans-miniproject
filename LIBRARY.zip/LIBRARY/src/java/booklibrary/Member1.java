/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booklibrary;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mr.Lopes
 */
@Entity
@Table(name = "member")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Member1.findAll", query = "SELECT m FROM Member1 m"),
    @NamedQuery(name = "Member1.findByMembID", query = "SELECT m FROM Member1 m WHERE m.membID = :membID"),
    @NamedQuery(name = "Member1.findByName", query = "SELECT m FROM Member1 m WHERE m.name = :name"),
    @NamedQuery(name = "Member1.findByAddress", query = "SELECT m FROM Member1 m WHERE m.address = :address"),
    @NamedQuery(name = "Member1.findByContact", query = "SELECT m FROM Member1 m WHERE m.contact = :contact"),
    @NamedQuery(name = "Member1.findByMemType", query = "SELECT m FROM Member1 m WHERE m.memType = :memType"),
    @NamedQuery(name = "Member1.findByJoindate", query = "SELECT m FROM Member1 m WHERE m.joindate = :joindate"),
    @NamedQuery(name = "Member1.findByMemexp", query = "SELECT m FROM Member1 m WHERE m.memexp = :memexp")})
public class Member1 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Memb_ID")
    private Integer membID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "Name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "Address")
    private String address;
    @Basic(optional = false)
    @NotNull
    @Column(name = "contact")
    private int contact;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "mem_type")
    private String memType;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Join_date")
    @Temporal(TemporalType.DATE)
    private Date joindate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Mem_exp")
    @Temporal(TemporalType.DATE)
    private Date memexp;

    public Member1() {
    }

    public Member1(Integer membID) {
        this.membID = membID;
    }

    public Member1(Integer membID, String name, String address, int contact, String memType, Date joindate, Date memexp) {
        this.membID = membID;
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.memType = memType;
        this.joindate = joindate;
        this.memexp = memexp;
    }

    public Integer getMembID() {
        return membID;
    }

    public void setMembID(Integer membID) {
        this.membID = membID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public String getMemType() {
        return memType;
    }

    public void setMemType(String memType) {
        this.memType = memType;
    }

    public Date getJoindate() {
        return joindate;
    }

    public void setJoindate(Date joindate) {
        this.joindate = joindate;
    }

    public Date getMemexp() {
        return memexp;
    }

    public void setMemexp(Date memexp) {
        this.memexp = memexp;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (membID != null ? membID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Member1)) {
            return false;
        }
        Member1 other = (Member1) object;
        if ((this.membID == null && other.membID != null) || (this.membID != null && !this.membID.equals(other.membID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "booklibrary.Member1[ membID=" + membID + " ]";
    }
    
}
